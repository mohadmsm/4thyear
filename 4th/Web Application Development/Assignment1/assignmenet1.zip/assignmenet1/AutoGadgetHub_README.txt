
AutoGadget Hub - Web Application

Welcome to AutoGadget Hub! Follow the steps below to run the web application locally.

Prerequisites
- Modern web browser (Chrome, Firefox, etc.)
- (Optional) Code editor (VS Code, Sublime Text, or any text editor)

Getting Started
1. unzip the folder.
2. Open the project folder (html) in your code editor.
3. Open `index.html` in a browser.
4. You can use Live Server (VS Code extension) for local server support.

 Pages
- Home (index.html)
- Shop (shop.html)
- About (about.html)
- Contact (contact.html)
- Sign In (signin.html) / Sign Up (signup.html)
- Help (help.html)
- Shopping cart (cart.html)
- checkout page (checkout.html)

Note!!
most the stuff in the shopping cart and checkout pages are examples and will be changed in the following weeks once java script is added. 

enjoy! Mohammed Al Shuaili 09/02/2025
