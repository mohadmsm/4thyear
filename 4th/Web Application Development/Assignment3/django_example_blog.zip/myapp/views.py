import json

from django.http import HttpRequest, JsonResponse
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.core.exceptions import PermissionDenied
from django.shortcuts import render, get_object_or_404, redirect

from .models import Post, Comment, PostCategory, PrivateNote, UserProfile
from .forms import NewPostForm, EditPostForm, NewCommentForm, NewCategoryForm, RegistrationForm, LoginForm, NewPrivateNoteForm, EditUserProfileForm, AjaxNewCategoryForm


def index(request: HttpRequest):
    context = {
    }
    return render(request, 'myapp/index.html', context)


def post_list(request: HttpRequest):
    posts = Post.objects.all().order_by('-created_at')
    context = {
        'posts': posts
    }
    return render(request, 'myapp/post_list.html', context)


def post_detail(request: HttpRequest, post_id):
    post = get_object_or_404(Post, id=post_id)
    comments = Comment.objects.filter(post=post)
    comment_form = NewCommentForm()
    context = {
        'post': post,
        'comments': comments,
        'comment_form': comment_form,
    }
    return render(request, 'myapp/post_detail.html', context)


@staff_member_required
def post_create(request: HttpRequest):
    if request.method == 'POST':
        form = NewPostForm(request.POST)
        if form.is_valid():
            post = Post.objects.create(
                title=form.cleaned_data['title'],
                content=form.cleaned_data['content'],
                event_date=form.cleaned_data['event_date'],
                category=form.cleaned_data['category'],
                author=request.user
            )
            return redirect('myapp:post_detail', post_id=post.id)
    else:
        form = NewPostForm()
    context = {
        'form': form,
    }
    return render(request, 'myapp/post_create.html', context)


@staff_member_required
def post_edit(request: HttpRequest, post_id: int):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        form = EditPostForm(request.POST)
        if form.is_valid():
            post.content = form.cleaned_data['content']
            post.event_date = form.cleaned_data['event_date']
            post.category = form.cleaned_data['category']
            post.save()
            return redirect('myapp:post_detail', post_id=post.id)
    else:
        initial = {
            'content': post.content,
            'category': post.category,
            'event_date': post.event_date,
        }
        form = EditPostForm(initial=initial)
    context = {
        'form': form,
        'post': post
    }
    return render(request, 'myapp/post_edit.html', context)


@staff_member_required
def post_delete(request: HttpRequest, post_id: int):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        post.delete()
        return redirect('myapp:post_list')
    context = {
        'post': post
    }
    return render(request, 'myapp/post_confirm_delete.html', context)


@login_required
def comment_add(request: HttpRequest, post_id: int):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        form = NewCommentForm(request.POST)
        if form.is_valid():
            Comment.objects.create(
                post=post,
                user=request.user,
                content=form.cleaned_data['content']
            )
        else:
            comments = Comment.objects.filter(post=post)
            context = {
                'comment_form': form,
                'comments': comments,
                'post': post,
            }
            return render(request, 'myapp/post_detail.html', context)
    return redirect('myapp:post_detail', post_id=post.id)


@login_required
def comment_delete(request: HttpRequest, comment_id: int):
    comment = get_object_or_404(Comment, id=comment_id)
    if request.user == comment.user or request.user.is_staff:
        comment.delete()
    else:
        raise PermissionDenied('User does not have permission to delete this comment')
    return redirect('myapp:post_detail', post_id=comment.post.id)


@login_required
def privatenote_list(request: HttpRequest):
    notes = PrivateNote.objects.filter(user=request.user)
    if request.method == 'POST':
        form = NewPrivateNoteForm(request.POST)
        if form.is_valid():
            PrivateNote.objects.create(
                user=request.user,
                note=form.cleaned_data['note']
            )
            return redirect('myapp:privatenote_list')
    else:
        form = NewPrivateNoteForm()
    context = {
        'notes': notes,
        'form': form
    }
    return render(request, 'myapp/privatenote_list.html', context)


@staff_member_required
def category_list(request: HttpRequest):
    categories = PostCategory.objects.all()
    if request.method == 'POST':
        form = NewCategoryForm(request.POST)
        if form.is_valid():
            PostCategory.objects.create(
                name=form.cleaned_data['name'],
            )
            return redirect('myapp:category_list')
    else:
        form = NewCategoryForm()
    context = {
        'form': form,
        'categories': categories,
    }
    return render(request, 'myapp/category_list.html', context)


@staff_member_required
def category_delete(request: HttpRequest, category_id: int):
    category = get_object_or_404(PostCategory, id=category_id)
    if request.method == 'POST':
        category.delete()
    return redirect('myapp:category_list')


def user_registration(request: HttpRequest):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password']
            )
            profile = UserProfile.objects.create(
                user=user,
                interests=form.cleaned_data['interests'])
            return redirect('myapp:login')
    else:
        form = RegistrationForm()
    context = {
        'form': form,
    }
    return render(request, 'myapp/register.html', context)


def user_login(request: HttpRequest):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('myapp:post_list')
            else:
                form.add_error(None, 'Invalid username or password.')
    else:
        form = LoginForm()
    context = {
        'form': form,
    }
    return render(request, 'myapp/login.html', context)


@login_required
def user_logout(request: HttpRequest):
    logout(request)
    return redirect('myapp:post_list')


@login_required
def profile_edit(request: HttpRequest):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    if request.method == 'POST':
        form = EditUserProfileForm(request.POST)
        if form.is_valid():
            user_profile.interests = form.cleaned_data['interests']
            user_profile.save()
            return redirect('myapp:profile_edit')
    else:
        initial = {
            'interests': user_profile.interests,
        }
        form = EditUserProfileForm(initial=initial)
    context = {
        'form': form,
    }
    return render(request, 'myapp/profile_edit.html', context)


def profile_detail(request: HttpRequest, username: str):
    target_user = get_object_or_404(User, username=username)
    context = {
        'target_user': target_user,
    }
    return render(request, 'myapp/profile_detail.html', context)


@staff_member_required
def category_ajax_page(request: HttpRequest):
    context = {
    }
    return render(request, 'myapp/category_ajax.html', context)


@staff_member_required
def ajax_category_list(request: HttpRequest):
    try:
        if not request.method == 'GET':
            raise Exception('Method must be GET request')
    except:
        return JsonResponse({'success': False, 'error': 'Invalid request.'}, status=400)
    categories = PostCategory.objects.all()
    category_list = []
    for category in categories:
        category_list.append({
            'id': category.id,
            'name': category.name
        })
    return JsonResponse({'category_list': category_list})


@staff_member_required
def ajax_category_add(request: HttpRequest):
    try:
        if not request.method == 'POST':
            raise Exception('Method must be POST request')
        data = json.loads(request.body)
    except:
        return JsonResponse({'success': False, 'error': 'Invalid request.'}, status=400)

    form = AjaxNewCategoryForm(data)
    if form.is_valid():
        category = PostCategory.objects.create(
            name=form.cleaned_data['name'],
        )
        return JsonResponse({
            'success': True,
            'category': {
                'id': category.id,
                'name': category.name
            }
        })
    else:
        return JsonResponse({'success': False, 'errors': form.errors}, status=400)


@staff_member_required
def ajax_category_delete(request: HttpRequest):
    try:
        if not request.method == 'POST':
            raise Exception('Method must be POST request')
        data = json.loads(request.body)
    except:
        return JsonResponse({'success': False, 'error': 'Invalid request.'}, status=400)
    category_id = data.get('category_id')
    if not category_id:
        return JsonResponse({'success': False, 'error': 'Category ID is required.'}, status=400)

    category = get_object_or_404(PostCategory, id=category_id)
    category.delete()
    return JsonResponse({'success': True})