from django.contrib import admin
from .models import Post, PostCategory, Comment, PrivateNote, UserProfile


@admin.register(PostCategory)
class PostCategoryAdmin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'category', 'created_at']


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['post', 'user', 'created_at']


@admin.register(PrivateNote)
class PrivateNoteAdmin(admin.ModelAdmin):
    list_display = ['user', 'note', 'created_at']


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user__username']
