from django import forms
from django.contrib.auth.models import User
from django.core.validators import RegexValidator

from  .models import PostCategory, Post


class NewPostForm(forms.Form):
    title = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={'class': 'example-css-class', 'placeholder': 'Post Title'})
    )
    content = forms.CharField(
        widget=forms.Textarea(attrs={'class': 'example-css-class', 'placeholder': 'Content'})
    )
    category = forms.ModelChoiceField(
        required=False,
        queryset=PostCategory.objects.all(),
        widget=forms.Select(attrs={'class': 'example-css-class'})
    )
    event_date = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'example-css-class'})
    )

    def clean_title(self):
        title = self.cleaned_data.get('title')
        if len(title) < 10:
            raise forms.ValidationError('Title is too short.')
        if Post.objects.filter(title=title).exists():
            raise forms.ValidationError('A post with this title already exists.')
        return title


class EditPostForm(forms.Form):
    content = forms.CharField(
        widget=forms.Textarea(attrs={'class': 'example-css-class', 'placeholder': 'Content'})
    )
    category = forms.ModelChoiceField(
        required=False,
        queryset=PostCategory.objects.all(),
        widget=forms.Select(attrs={'class': 'example-css-class'})
    )
    event_date = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'example-css-class'})
    )
    

class NewCommentForm(forms.Form):
    content = forms.CharField(
        widget=forms.Textarea(attrs={'placeholder': 'Your comment'})
    )

    def clean_content(self):
        content = self.cleaned_data.get('content')
        if 'http://' in content or 'https://' in content:
            raise forms.ValidationError('Links are not allowed in comments')
        return content


class NewCategoryForm(forms.Form):
    name = forms.CharField(
        max_length=100,
        widget=forms.TextInput(),
        validators=[
            RegexValidator(
                regex=r'^[A-Za-z0-9\-]+$',
                message='Category names must be an alphanumberic/hyphenated string'
            )
        ],
    )

    def clean_name(self):
        name = self.cleaned_data.get('name')
        if PostCategory.objects.filter(name=name).exists():
            raise forms.ValidationError('A category with this name already exists.')
        return name


class RegistrationForm(forms.Form):
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'class': 'example-css-class', 'placeholder': 'Username'})
    )
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={'class': 'example-css-class', 'placeholder': 'Email'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'example-css-class', 'placeholder': 'Password'})
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'example-css-class', 'placeholder': 'Confirm Password'})
    )
    interests = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'class': 'example-css-class', 'placeholder': 'User interests'})
    )

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError('Username already registered.')
        return username
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('Email already registered.')
        return email

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        confirm = cleaned_data.get('confirm_password')
        if password and confirm and password != confirm:
            raise forms.ValidationError('Passwords do not match')
        return cleaned_data


class LoginForm(forms.Form):
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'placeholder': 'Username'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': 'Password'})
    )


class NewPrivateNoteForm(forms.Form):
    note = forms.CharField(
        required=True,
        widget=forms.Textarea(attrs={'placeholder': 'Your private note'})
    )


class EditUserProfileForm(forms.Form):
    interests = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'placeholder': 'User interests'})
    )


class AjaxNewCategoryForm(forms.Form):
    name = forms.CharField(
        max_length=100,
        widget=forms.TextInput(),
        validators=[
            RegexValidator(
                regex=r'^[A-Za-z0-9\-]+$',
                message='Category names must be an alphanumberic/hyphenated string'
            )
        ],
    )

    def clean_name(self):
        name = self.cleaned_data.get('name')
        if PostCategory.objects.filter(name=name).exists():
            raise forms.ValidationError('A category with this name already exists.')
        return name