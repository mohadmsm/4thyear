from django.urls import path

from . import views

app_name='myapp'
urlpatterns = [
    path('', views.index, name='index'),
    path('categories/', views.category_list, name='category_list'),
    path('categories/<int:category_id>/delete/', views.category_delete, name='category_delete'),
    path('categories_ajax/', views.category_ajax_page, name='category_ajax'),
    path('post/', views.post_list, name='post_list'),
    path('post/<int:post_id>/', views.post_detail, name='post_detail'),
    path('post/create/', views.post_create, name='post_create'),
    path('post/<int:post_id>/edit/', views.post_edit, name='post_edit'),
    path('post/<int:post_id>/delete/', views.post_delete, name='post_delete'),
    path('post/<int:post_id>/comment/add/', views.comment_add, name='add_comment'),
    path('comment/<int:comment_id>/delete/', views.comment_delete, name='delete_comment'),
    path('notes/', views.privatenote_list, name='privatenote_list'),
    path('profile/', views.profile_edit, name='profile_edit'),
    path('profile/<str:username>', views.profile_detail, name='profile_detail'),
    path('register/', views.user_registration, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('ajax/category_list/', views.ajax_category_list, name='ajax_category_list'),
    path('ajax/category_add/', views.ajax_category_add, name='ajax_category_add'),
    path('ajax/category_delete/', views.ajax_category_delete, name='ajax_category_delete'),
]
