from django.test import TestCase

# Create your tests here.
class ExampleTest(TestCase):
    def test_example(self):
        assert 1 == 1