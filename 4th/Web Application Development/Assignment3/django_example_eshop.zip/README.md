# eShop Example

## Requirements

* Python 3.9+
* Visual Studio Code
  * Extension: "Python" (ms-python.python)

## Instructions

To run the project:

* Open in Visual Studio code
* F1 -> "Python: Create Environment" -> "Venv" -> ... "requirements.txt"
* F1 -> "Python: Select Interpreter" -> ".venv"
* "Run and Debug"
  * `manage.py makemigrations`
  * `manage.py migrate`
  * `manage.py createsuperuser`
  * `manage.py runserver`
* Open <http://localhost:8000> in the web browser.


## Creating a staff account

* Open <http://localhost:8000/admin> in the web browser.
* Login with these credentials:
  * Username: admin
  * Password: admin
* Create a new "User" object
  * Enable "Staff status"
* Create a new "User Profile" object
  * Set "User" to be the user you just made
* Logout
* Open <http://localhost:8000/login>
* Login with the staff user's credentials
