from django.contrib import admin
from .models import ProductCategory, Product, CartItem, Order, OrderItem, UserProfile


@admin.register(ProductCategory)
class ProductCategoryAdmin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'product_code', 'category__name', 'price', 'stock']
    select_related = ['category']


@admin.register(CartItem)
class CartItemAdmin(admin.ModelAdmin):
    list_display = ['user__username', 'product__name', 'quantity']
    select_related = ['user', 'product']

class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'user__username', 'created', 'total']
    inlines = [
        OrderItemInline,
    ]


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user__username', 'user__email']
    select_related = ['user']
