from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from decimal import Decimal

from .models import Product, ProductCategory, CartItem, Order, OrderItem, UserProfile
from .utils import valid_luhn_checksum


class UtilityFunctionsTest(TestCase):
    def test_luhn_validator(self):
        self.assertEqual(valid_luhn_checksum('5555555555554444'), True)
        self.assertEqual(valid_luhn_checksum('5555555155554444'), False)
        self.assertEqual(valid_luhn_checksum('4111111111111111'), True)
        self.assertEqual(valid_luhn_checksum('4111111211111111'), False)


class CheckoutProcessTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.category = ProductCategory.objects.create(name='Test Category')
        self.product = Product.objects.create(
            category=self.category,
            name='Test Product',
            description='Test Product Description.',
            product_code='TEST123',
            price=Decimal('10.00'),
            stock=5
        )
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass',
            email='test@example.com'
        )
        self.user_profile = UserProfile.objects.create(
            user=self.user,
            address='123 Test Address',
            phone_number='+1234567890'
        )
        self.cart_item = CartItem.objects.create(
            user=self.user,
            product=self.product,
            quantity=2
        )
        self.client.login(username='testuser', password='testpass')

    def test_checkout_success(self):
        valid_post_data = {
            'credit_card_number': '4242424242424242',
            'cvv': '123',
            'expiry_month': '12',
            'expiry_year': '2030',
        }
        response = self.client.post(reverse('myapp:checkout'), valid_post_data)
        self.assertRedirects(response, reverse('myapp:order_history'))

        order = Order.objects.get(user=self.user)
        self.assertEqual(order.address, '123 Test Address')
        self.assertEqual(order.total, Decimal('20.00'))

        order_item = OrderItem.objects.get(order=order)
        self.assertEqual(order_item.quantity, 2)
        self.assertEqual(order_item.price, self.product.price)

        self.product.refresh_from_db()
        self.assertEqual(self.product.stock, 3)

        self.assertFalse(CartItem.objects.filter(user=self.user).exists())

        response = self.client.get(reverse('myapp:order_history'))
        self.assertContains(response, 'Test Product', status_code=200)


    def test_checkout_insufficient_stock(self):
        self.cart_item.quantity = 10
        self.cart_item.save()

        valid_post_data = {
            'credit_card_number': '4242424242424242',
            'cvv': '123',
            'expiry_month': '12',
            'expiry_year': '2030',
        }
        response = self.client.post(reverse('myapp:checkout'), valid_post_data)
        self.assertContains(response, 'Insufficient stock', status_code=200)
        self.assertContains(response, 'Checkout failed', status_code=200)

        self.assertFalse(Order.objects.filter(user=self.user).exists())

        self.product.refresh_from_db()
        self.assertEqual(self.product.stock, 5)

        self.assertTrue(CartItem.objects.filter(user=self.user).exists())

        response = self.client.get(reverse('myapp:order_history'))
        self.assertNotContains(response, 'Test Product', status_code=200)