from django import forms
from django.contrib.auth.models import User
from django.core.validators import RegexValidator

from .models import ProductCategory
from .utils import valid_luhn_checksum


class CategoryForm(forms.Form):
    name = forms.CharField(
        max_length=100,
        widget=forms.TextInput(),
        label='Category Name'
    )


class UpdateCartForm(forms.Form):
    quantity = forms.IntegerField(
        min_value=1,
        widget=forms.NumberInput(),
        label='Quantity'
    )


class ProductSearchForm(forms.Form):
    query = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Search products...'}),
        label='Search'
    )


class CheckoutForm(forms.Form):
    credit_card_number = forms.CharField(
        max_length=16, min_length=13,
        validators=[
            RegexValidator(
                regex=r'^\d{13,16}$',
                message='Credit card number must be between 13 and 16 digits.'
            )
        ],
        widget=forms.TextInput(attrs={'class': 'example-css-class', 'placeholder': 'Credit Card Number'})
    )
    cvv = forms.CharField(
        max_length=4, min_length=3,
        validators=[
            RegexValidator(
                regex=r'^\d{3}$',
                message='CVV must be 3 digits.'
            )
        ],
        widget=forms.TextInput(attrs={'class': 'example-css-class', 'placeholder': 'CVV'}),
        label='CVV'
        
    )
    expiry_month = forms.ChoiceField(
        choices=[('1','1'), ('2','2'), ('3','3'), ('4','4'), ('5','5'), ('6','6'), ('7','7'), ('8','8'), ('9','9'), ('10','10'), ('11','11'), ('12','12')],
        widget=forms.Select(attrs={'class': 'example-css-class'}),
        label='Expiry Month'
    )
    expiry_year = forms.ChoiceField(
        choices=[('2025','2025'), ('2026','2026'), ('2027','2027'), ('2028','2028'), ('2029','2029'), ('2030','2030'), ('2031','2031'), ('2032','2032'), ('2033','2033'), ('2034','2034'), ('2035','2035')],
        widget=forms.Select(attrs={'class': 'example-css-class'}),
        label='Expiry Year'
    )

    def clean_credit_card_number(self):
        card_number = self.cleaned_data.get('credit_card_number')
        if valid_luhn_checksum(card_number) != True:
            raise forms.ValidationError("Invalid credit card number.")
        return card_number



class AddProductForm(forms.Form):
    category = forms.ModelChoiceField(
        required=False,
        queryset=ProductCategory.objects.all(),
        widget=forms.Select(),
        label='Category'
    )
    name = forms.CharField(
        max_length=200,
        widget=forms.TextInput(),
        label='Name'
    )
    description = forms.CharField(
        widget=forms.Textarea(),
        label='Description'
    )
    product_code = forms.CharField(
        max_length=50,
        widget=forms.TextInput(),
        label='Product Code'
    )
    image = forms.FileField(
        required=False,
        widget=forms.ClearableFileInput(
        ),
        label='Image'
    )
    price = forms.DecimalField(
        max_digits=10, decimal_places=2,
        widget=forms.NumberInput(),
        label='Price'
    )

class EditProductForm(forms.Form):
    category = forms.ModelChoiceField(
        required=False,
        queryset=ProductCategory.objects.all(),
        widget=forms.Select(),
        label='Category'
    )
    description = forms.CharField(
        widget=forms.Textarea(),
        label='Description'
    )
    image = forms.FileField(
        required=False,
        widget=forms.ClearableFileInput(),
        label='Image'
    )
    price = forms.DecimalField(
        max_digits=10, decimal_places=2,
        widget=forms.NumberInput(),
        label='Price'
    )
    stock = forms.IntegerField(
        min_value=0,
        widget=forms.NumberInput(),
        label='Stock'
    )


class UserRegistrationForm(forms.Form):
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'class': 'example-css-class'}),
        label='Username'
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'example-css-class'}),
        label='Password'
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'example-css-class'}),
        label='Confirm Password'
    )
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={'class': 'example-css-class'}),
        label='Email'
    )
    address = forms.CharField(
        max_length=255,
        widget=forms.Textarea(attrs={'class': 'example-css-class'}),
        label='Address'
    )
    phone_number = forms.CharField(
        max_length=20,
        widget=forms.TextInput(attrs={'class': 'example-css-class'}),
        validators=[
            RegexValidator(
                regex=r'^\+?1?\d{9,15}$',
                message='Phone number must consist of 9-15 digits with optional + prefix.'
            )
        ],
        label='Phone Number'
    )

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('Email already registered.')
        return email

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        confirm = cleaned_data.get('confirm_password')
        if password and confirm and password != confirm:
            raise forms.ValidationError('Passwords do not match')
        return cleaned_data


class UserLoginForm(forms.Form):
    email = forms.EmailField(
        widget=forms.EmailInput(),
        label='Email'
    )
    password = forms.CharField(
        widget=forms.PasswordInput(),
        label='Password'
    )


class EditUserProfileForm(forms.Form):
    email = forms.EmailField(
        widget=forms.EmailInput(),
        label='Email'
    )
    address = forms.CharField(
        max_length=255,
        widget=forms.Textarea(),
        label='Address'
    )
    phone_number = forms.CharField(
        max_length=20,
        widget=forms.TextInput(),
        validators=[
            RegexValidator(
                regex=r'^\+?1?\d{9,15}$',
                message='Phone number must consist of 9-15 digits with optional + prefix.'
            )
        ],
        label='Phone Number'
    )
