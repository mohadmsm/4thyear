window.addEventListener("load", (event) => {
    console.log("JavaScript loaded.");
});
