def valid_luhn_checksum(card_number: str) -> bool:
    """
    Implementation of 
    https://en.wikipedia.org/wiki/Luhn_algorithm

    Example card numbers that return "True":
        '5555555555554444'
        '4111111111111111'
    """
    digits = [int(d) for d in card_number]
    total = 0
    for i, digit in enumerate(reversed(digits)):
        if i % 2 == 1:
            doubled = digit * 2
            total += doubled if doubled < 10 else doubled - 9
        else:
            total += digit
    if total % 10 == 0:
        return True
    return False