from django.http import HttpRequest, HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.db import transaction
from django.contrib.auth.models import User

from .models import Product, ProductCategory, CartItem, Order, OrderItem, UserProfile
from .forms import UpdateCartForm, CategoryForm, ProductSearchForm, CheckoutForm, AddProductForm, EditProductForm, UserRegistrationForm, UserLoginForm, EditUserProfileForm


def index(request: HttpRequest):
    context = {}
    return render(request, 'myapp/index.html', context)


def product_list(request: HttpRequest):
    products = Product.objects.all()
    context = {
        'products': products
    }
    return render(request, 'myapp/product_list.html', context)


def product_search(request):
    form = ProductSearchForm(request.GET or None)
    products = Product.objects.all()
    if form.is_valid():
        query = form.cleaned_data.get('query')
        if query:
            products = products.filter(name__icontains=query)
    context = {
        'form': form,
        'products': products,
    }
    return render(request, 'myapp/product_search.html', context)


def product_detail(request: HttpRequest, product_id: int):
    product = get_object_or_404(Product, id=product_id)
    cart_quantity = 0
    if request.user.is_authenticated and CartItem.objects.filter(user=request.user, product=product).exists():
        cart_item = CartItem.objects.get(user=request.user, product=product)
        cart_quantity = cart_item.quantity
    initial = {
        'quantity': cart_quantity,
    }
    form = UpdateCartForm(initial=initial)
    context = {
        'product': product,
        'form': form,
    }
    return render(request, 'myapp/product_detail.html', context)


@login_required
def product_update_cart(request: HttpRequest, product_id: int):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = UpdateCartForm(request.POST)
        if form.is_valid():
            quantity = form.cleaned_data['quantity']
            if quantity == 0:
                CartItem.objects.filter(user=request.user, product=product).delete()
                messages.success(request, 'Product removed from cart.')
                return redirect('myapp:cart')
            if product.stock < quantity:
                form.add_error('quantity', 'Not enough stock available.')
                context = {
                    'product': product,
                    'form': form,
                }
                return render(request, 'myapp/product_detail.html', context)
            cart_item, created = CartItem.objects.get_or_create(user=request.user, product=product)
            cart_item.quantity = quantity
            cart_item.save()
            messages.success(request, 'Product updated in cart.')
            return redirect('myapp:cart')
    return redirect('myapp:product_list')


@login_required
def cart(request: HttpRequest):
    cart_items = CartItem.objects.filter(user=request.user)
    cart_total = 0
    for cart_item in cart_items:
        cart_total += cart_item.product.price * cart_item.quantity
    context = {
        'cart_items': cart_items,
        'cart_total': cart_total,
    }
    return render(request, 'myapp/cart.html', context)


@login_required
def checkout(request: HttpRequest):
    cart_items = CartItem.objects.filter(user=request.user)
    if not cart_items.exists():
        messages.error(request, 'Your cart is empty.')
        return redirect('myapp:product_list')
    if request.method == 'POST':
        form = CheckoutForm(request.POST)
        if form.is_valid():
            try:
                with transaction.atomic():
                    user_profile = UserProfile.objects.get(user=request.user)
                    order = Order.objects.create(
                        user=request.user,
                        address=user_profile.address,
                        total=0,
                    )
                    total = 0
                    for item in cart_items:
                        product = item.product
                        if product.stock < item.quantity:
                            raise Exception(f'Insufficient stock for {product.name}')
                        product.stock -= item.quantity
                        product.save()
                        OrderItem.objects.create(
                            order=order,
                            product=product,
                            quantity=item.quantity,
                            price=product.price,
                        )
                        total += product.price * item.quantity
                    order.total = total
                    order.save()
                    cart_items.delete()
                    messages.success(request, 'Checkout successful!')
                    return redirect('myapp:order_history')
            except Exception as e:
                messages.error(request, f'Checkout failed: {str(e)}')
    else:
        form = CheckoutForm()
    context = {
        'form': form
    }
    return render(request, 'myapp/checkout.html', context)


@login_required
def order_history(request: HttpRequest):
    orders = Order.objects.filter(user=request.user).order_by('-created')
    context = {
        'orders': orders
    }
    return render(request, 'myapp/order_history.html', context)


@staff_member_required
def staff_product_add(request: HttpRequest):
    if request.method == 'POST':
        form = AddProductForm(request.POST, request.FILES)
        if form.is_valid():
            product = Product.objects.create(
                category=form.cleaned_data['category'],
                name=form.cleaned_data['name'],
                description=form.cleaned_data['description'],
                product_code=form.cleaned_data['product_code'],
                image=form.cleaned_data['image'],
                price=form.cleaned_data['price'],
                stock=0,
            )
            messages.success(request, 'Product added successfully.')
            return redirect('myapp:product_detail', product_id=product.id)
    else:
        form = AddProductForm()
    context = {
        'form': form,
    }
    return render(request, 'myapp/staff_product_add.html', context)


@staff_member_required
def staff_product_edit(request: HttpRequest, product_id: int):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = EditProductForm(request.POST, request.FILES)
        if form.is_valid():
            product.category = form.cleaned_data['category']
            product.description = form.cleaned_data['description']
            if 'image' in request.FILES:
                product.image = request.FILES['image']
            product.price = form.cleaned_data['price']
            product.stock = form.cleaned_data['stock']
            product.save()
            messages.success(request, 'Product updated successfully.')
            return redirect('myapp:product_detail', product_id=product.id)
    else:
        initial = {
            'category': product.category,
            'description': product.description,
            'price': product.price,
            'stock': product.stock,
        }
        form = EditProductForm(initial=initial)
    context = {
        'form': form,
        'action': 'Edit'
    }
    return render(request, 'myapp/staff_product_edit.html', context)


@staff_member_required
def category_list(request: HttpRequest):
    categories = ProductCategory.objects.all()
    if request.method == "POST":
        form = CategoryForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            ProductCategory.objects.create(name=name)
            messages.success(request, 'Category created successfully.')
            return redirect('myapp:category_list')
    else:
        form = CategoryForm()
    context = {
        'categories': categories,
        'form': form
    }
    return render(request, 'myapp/staff_category_list.html', context)


@staff_member_required
def category_edit(request: HttpRequest, category_id: int):
    category = get_object_or_404(ProductCategory, id=category_id)
    if request.method == "POST":
        form = CategoryForm(request.POST)
        if form.is_valid():
            category.name = form.cleaned_data['name']
            category.save()
            messages.success(request, 'Category updated successfully.')
            return redirect('myapp:category_list')
    else:
        initial = {
            'name': category.name
        }
        form = CategoryForm(initial=initial)
    context = {
        'form': form,
        'category': category
    }
    return render(request, 'myapp/staff_category_edit.html', context)


@staff_member_required
def category_delete(request: HttpRequest, category_id: int):
    category = get_object_or_404(ProductCategory, id=category_id)
    try:
        category.delete()
        messages.success(request, 'Category deleted successfully.')
    except Exception as e:
        messages.error(request, f'Unable to delete category: {str(e)}')
    return redirect('myapp:category_list')


def user_registration(request: HttpRequest):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            email = form.cleaned_data['email']
            address = form.cleaned_data['address']
            if User.objects.filter(username=username).exists():
                form.add_error('username', 'Username already exists.')
            else:
                user = User.objects.create_user(username=username, password=password, email=email)
                UserProfile.objects.create(user=user, address=address)
                messages.success(request, 'Registration successful. Please log in.')
                return redirect('myapp:login')
    else:
        form = UserRegistrationForm()
    context = {
        'form': form,
    }
    return render(request, 'myapp/user_registration.html', context)


def user_login(request: HttpRequest):
    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            try:
                user_obj = User.objects.get(email=email)
                user = authenticate(username=user_obj.username, password=password)
                if user:
                    login(request, user)
                    messages.success(request, 'Logged in successfully.')
                    return redirect('myapp:index')
                else:
                    form.add_error(None, 'Invalid credentials.')
            except User.DoesNotExist:
                form.add_error('email', 'User with this email does not exist.')
    else:
        form = UserLoginForm()
    context = {
        'form': form,
    }
    return render(request, 'myapp/user_login.html', context)


@login_required
def user_logout(request: HttpRequest):
    logout(request)
    messages.success(request, 'Logged out successfully.')
    return redirect('myapp:index')


@login_required
def profile_edit(request: HttpRequest):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    if request.method == 'POST':
        form = EditUserProfileForm(request.POST)
        if form.is_valid():
            user_profile.address = form.cleaned_data['address']
            user_profile.phone_number = form.cleaned_data['phone_number']
            user_profile.save()
            messages.success(request, 'Profile updated successfully.')
            return redirect('myapp:profile_edit')
    else:
        initial = {
            'email': request.user.email,
            'address': user_profile.address,
            'phone_number': user_profile.phone_number,
        }
        form = EditUserProfileForm(initial=initial)
    context = {
        'form': form,
    }
    return render(request, 'myapp/user_profile.html', context)
