from django.urls import path
from . import views

app_name = 'myapp'
urlpatterns = [
    path('', views.index, name='index'),
    path('product/', views.product_list, name='product_list'),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('product/<int:product_id>/update-cart', views.product_update_cart, name='product_update_cart'),
    path('search/', views.product_search, name='product_search'),
    path('cart/', views.cart, name='cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('orders/', views.order_history, name='order_history'),
    path('staff/add-product/', views.staff_product_add, name='staff_product_add'),
    path('staff/product/<int:product_id>/edit', views.staff_product_edit, name='staff_product_edit'),
    path('staff/category/', views.category_list, name='category_list'),
    path('staff/category/<int:category_id>/edit', views.category_edit, name='category_edit'),
    path('staff/category/<int:category_id>/delete', views.category_delete, name='category_delete'),
    path('register/', views.user_registration, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('profile/', views.profile_edit, name='profile_edit'),
]
